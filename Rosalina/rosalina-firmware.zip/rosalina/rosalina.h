/* Copyright 2022 Carter Codell
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#pragma once

#include "quantum.h"

#define XXX KC_NO

#define LAYOUT_split_space( \
    k7, k8, k9, kesc, kq, kw, ke, kr, kt, ky, ku, ki, ko, kp,    kbs, \
    k4, k5, k6, ktab,  ka, ks, kd, kf, kg, kh, kj, kk, kl,       kent, \
    k1, k2, k3, klshf,   kz, kx, kc, kv, kb, kn, km, kcom, kper, krshf,\
    k0, kns1, kns2, klhyp, klsup, klmeta, krspc, klspc, krmeta, krsup, krhyp \
    ) { \
        { k7,   k9,   kesc,  kw,     kr,    ky,     ku,   ko }, \
        { k8,   k5,   kq,    ke,     kt,    kg,     ki,   kp }, \
        { k4,   k6,   ktab,  ks,     kf,    kh,     kj,   kbs }, \
        { k1,   k2,   ka,    kd,     kc,    kb,     kk,   kent }, \
        { k0,   k3,   klshf, kz,     kv,    kn,     kl,   kper }, \
        { kns1, kns2, klhyp, kx,     klspc, krmeta, km,   krshf }, \
        { XXX,  XXX,  klsup, klmeta, krspc, krsup,  kcom, krhyp } \
    }

#define LAYOUT_big_space( \
    k7, k8, k9, kesc, kq, kw, ke, kr, kt, ky, ku, ki, ko, kp,    kbs, \
    k4, k5, k6, ktab,  ka, ks, kd, kf, kg, kh, kj, kk, kl,       kent, \
    k1, k2, k3, klshf,   kz, kx, kc, kv, kb, kn, km, kcom, kper, krshf,\
    k0, kns1, kns2, klhyp, klsup, klmeta,      kspc,     krmeta, krhyp \
    ) { \
        { k7,   k9,   kesc,  kw,     kr,   ky,    ku,   ko }, \
        { k8,   k5,   kq,    ke,     kt,   kg,    ki,   kp }, \
        { k4,   k6,   ktab,  ks,     kf,   kh,    kj,   kbs }, \
        { k1,   k2,   ka,    kd,     kc,   kb,    kk,   kent }, \
        { k0,   k3,   klshf, kz,     kv,   kn,    kl,   kper }, \
        { kns1, kns2, klhyp, kx,     XXX,  XXX,   km,   krshf }, \
        { XXX,  XXX,  klsup, klmeta, kspc, krmeta, kcom, krhyp } \
    }
